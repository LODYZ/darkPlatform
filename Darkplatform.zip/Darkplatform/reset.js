try{
	document.getElementById('darkMode').remove();
	document.getElementById('darkModeEditor').remove();
	if(document.getElementsByTagName('df-messenger').length>0){
		document.getElementsByTagName('df-messenger')[0].style ? document.getElementsByTagName('df-messenger')[0].removeAttribute('style') : null;
	}
	
	if(document.getElementsByClassName('x-tip-tooltip-hint').length>0){
		document.getElementsByClassName('x-tip-tooltip-hint')[0].hidden ? document.getElementsByClassName('x-tip-tooltip-hint')[0].removeAttribute('hidden') : null;
		document.getElementsByClassName('x-shadow')[0].hidden ? document.getElementsByClassName('x-shadow')[0].removeAttribute('hidden') : null;
	}
	
}catch(e){
	console.log(e);
}